# Put initialization code in this file.

load(file.path(find.package("swirl"),
               "Courses/Statistical_Methods/Intro_to_ANOVA/",
               "HealthExam.rda"))
