qqnorm(fd, main="female diastolic blood pressure")
qqline(fd)